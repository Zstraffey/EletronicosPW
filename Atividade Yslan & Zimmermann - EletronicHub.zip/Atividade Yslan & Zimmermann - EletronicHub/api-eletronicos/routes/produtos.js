const express = require('express');
const router = express.Router();

let produtos = [
  {
    id: 1,
    nome: "Notebook Dell XPS 13",
    categoria: "Notebook",
    marca: "Dell",
    preco: 7999.99,
    estoque: 10
  },
  {
    id: 2,
    nome: "Notebook Acer Aspire 5",
    categoria: "Notebook",
    marca: "DELL",
    preco: 7.238,
    estoque: 31
  },
  {
    id: 3,
    nome: "Notebook Gamer ASUS TUF Gaming A15",
    categoria: "Notebook",
    marca: "Asus",
    preco: 4.604,
    estoque: 34
  },
  {
    id: 4,
    nome: "Notebook Core I7-1355U Dell",
    categoria: "Notebook",
    marca: "DELL",
    preco: 2.749,
    estoque: 17
  },
  {
    id: 5,
    nome: "Notebook Acer Aspire 5 A15-51M-54E6",
    categoria: "Notebook",
    marca: "Acer",
    preco: 3.099,
    estoque: 8
  },
];

// Listar todos os produtos
router.get('/', (req, res) => {
  res.json(produtos);
});

// Adicionar novo produto
router.post('/', (req, res) => {
  const novoProduto = req.body;
  novoProduto.id = produtos.length + 1;
  produtos.push(novoProduto);
  res.status(201).json(novoProduto);
});

// Atualizar produto pelo ID
router.put('/:id', (req, res) => {
  const id = parseInt(req.params.id);
  const index = produtos.findIndex(p => p.id === id);

  if (index !== -1) {
    produtos[index] = { id, ...req.body };
    res.json(produtos[index]);
  } else {
    res.status(404).json({ message: "Produto não encontrado." });
  }
});

// Deletar produto pelo ID
router.delete('/:id', (req, res) => {
  const id = parseInt(req.params.id);
  produtos = produtos.filter(p => p.id !== id);
  res.json({ message: "Produto removido com sucesso." });
});

module.exports = router;
