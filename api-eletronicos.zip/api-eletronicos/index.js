

const express = require('express');
const app = express();
const produtosRoute = require('./routes/produtos.js');

app.use(express.json());
app.use('/produtos', produtosRoute);

app.get('/', (req, res) => {
  res.send('Bem-vindo à API de Produtos!');
});

app.listen(3000, () => {
  console.log('API rodando em http://localhost:3000');
});
